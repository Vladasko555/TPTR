<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.






//Základní routy
$routes->get('/', 'Controller::home');
$routes->get('glitche', 'Controller::glitche');
$routes->get('TPTR', 'Controller::TPTR');
$routes->get('FAQ', 'Controller::FAQ');

//Glitche - tabulky
$routes->get('GlitcheGTA', 'Controller::GlitcheGTA');
$routes->get('GlitcheFn', 'Controller::GlitcheFn');
$routes->get('GlitcheLOL', 'Controller::GlitcheLOL');
$routes->get('GlitcheWOT', 'Controller::GlitcheWOT');
$routes->get('GlitcheCP77', 'Controller::GlitcheCP77');

//TPTR - tabulky
$routes->get('TPTRGTA', 'Controller::TPTRGTA');
$routes->get('TPTRFn', 'Controller::TPTRFn');
$routes->get('TPTRLOL', 'Controller::TPTRLOL');
$routes->get('TPTRWOT', 'Controller::TPTRWOT');
$routes->get('TPTRCP77', 'Controller::TPTRCP77');

//Jednotlivé články
$routes->get('clanky/(:num)', 'Controller::clanek/$1');

//Administrativa
$routes->get('admin', 'Controller::admin');
$routes->post('addclanek', 'Controller::addclanek');
$routes->delete('smazclanek/(:num)', 'Controller::smazclanek/$1');
$routes->post('upravclanek', 'Controller::upravclanek');













/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
