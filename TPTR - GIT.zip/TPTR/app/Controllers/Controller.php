<?php

namespace App\Controllers;

use App\Models\ModelTPTR;
use stdClass;

class Controller extends BaseController
{
    var $db;
    var $model;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->model = new ModelTPTR(); // uložím si tvorbu modelu do proměnné třídy
    }

    //Základní metody
    public function home()
    {
        $data["title"] = "home";
        echo view('home', $data);
    }

    public function glitche()
    {
        $data["title"] = "glitche";
        echo view('glitche', $data);
    }

    public function TPTR()
    {
        $data["title"] = "TPTR";
        echo view('TPTR', $data);
    }

    public function FAQ()
    {
        $data["title"] = "FAQ";
        echo view('FAQ', $data);
    }










    //TPTR - metody
    public function TPTRGTA()
    {

        $data['data'] = $this->model->getTPTRGTA();

        return view('TPTRGTA', $data);
    }

    public function TPTRFn()
    {

        $data['data'] = $this->model->getTPTRFn();

        return view('TPTRFn', $data);
    }

    public function TPTRWOT()
    {

        $data['data'] = $this->model->getTPTRWOT();

        return view('TPTRWOT', $data);
    }

    public function TPTRCP77()
    {

        $data['data'] = $this->model->getTPTRCP77();

        return view('TPTRCP77', $data);
    }

    public function TPTRLOL()
    {

        $data['data'] = $this->model->getTPTRLOL();

        return view('TPTRLOL', $data);
    }



    //Glitche - metody
    public function GlitcheGTA()
    {

        $data['data'] = $this->model->getGlitcheGTA();

        return view('GlitcheGTA', $data);
    }

    public function GlitcheWOT()
    {

        $data['data'] = $this->model->getGlitcheWOT();

        return view('GlitcheWOT', $data);
    }

    public function GlitcheFn()
    {

        $data['data'] = $this->model->getGlitcheFn();

        return view('GlitcheFn', $data);
    }

    public function GlitcheLOL()
    {

        $data['data'] = $this->model->getGlitcheLOL();

        return view('GlitcheLOL', $data);
    }

    public function GlitcheCP77()
    {

        $data['data'] = $this->model->getGlitcheCP77();

        return view('GlitcheCP77', $data);
    }



    //Metoda na tabulky
    public function clanek($id)
    {
        $data['clanek'] = $this->model->getclanek($id);
        $data["title"] = "claneketail";
        return view('clanek', $data);
    }



    //Administrativní část
    public function admin()
    {
        $data["title"] = "admin";
        return view('admin');
    }

    public function addclanek()
    {
        //prazdny array $data
        $data = [];
        //heleper funkce formy
        helper('form');

        //overi jestli metoda post nebo get
        if ($this->request->getMethod() == 'post') {
            $formData = $this->request->getPost();

            if ($this->model->addClanek($formData))
                return redirect()->to("/admin");
        } else {
            return $data['message'] = "Access restricted to POST method only!";
        }

        return $data;
    }

    public function smazclanek($id)
    {
        // Create an instance of the ClankyModel
        $model = new ModelTPTR();

        // Delete the record from the database
        if ($this->request->getMethod() == 'delete') {
            $formData = $this->request->getPost();

            if ($this->model->smazClanek($formData))
                return redirect()->to("/admin");
        } else {
            return $data['message'] = "Access restricted to POST method only!";
        }
    }

    // Optionally, you can redirect to a success page or do something else


    public function edit()
    {
        $data["title"] = "edit";
        return view('edit');
    }
}






    /* public function add()
    {
        // Create an instance of the ModelTPTR
        $this->model = new ModelTPTR();

        // Get the data from your form or input
        $data = [
            'title' => $this->request->getPost('nadpis'),
            'autor' => $this->request->getPost('autor'),
            'datum_napsani' => $this->request->getPost('datum_napsani'),
            'text' => $this->request->getPost('text'),
            'hra' => $this->request->getPost('hra'),
            // Add more fields as needed
        ];

        // Insert the data into the database
        // $model->insert($data);

        // Optionally, you can redirect to a success page or do something else
        return redirect()->to('/TPTRBlog');
    }*/
