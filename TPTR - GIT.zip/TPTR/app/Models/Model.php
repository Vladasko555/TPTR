<?php

namespace App\Models;


use Config\Database;

class Model
{
    var $db;
    function __construct()
    {
        $this->db = \Config\Database::connect();
    }


    function getDVDs()
    {

        $builder = $this->db->table('dvd');
        $builder->select('nazev, rok_vydani');

        $data = $builder->get()->getResult();
        return $data;
    }

    function getDVDsByYear($rok) {

        $builder = $this->db->table('dvd');
        $builder->join('kategorie', 'kategorie.id = dvd.kategorie', 'inner'); 
        $builder->select('dvd.nazev, kategorie.nazev as nazevK, dvd.cena_s_dph as cenaDPH,');
        $builder->where('dvd.rok_vydani', $rok);
        $builder->orderBy('dvd.nazev', 'asc');
    
        $data = $builder->get()->getResult();
        return $data;
    }
    
}
