<?php

namespace App\Models;


use Config\Database;

class ModelTPTR extends Model
{
    var $db;
    protected $table = 'clanky'; // Name of the database table
    protected $allowedFields = [
        'nadpis',
        'autor',
        'datum_napsani',
        'text',
        'hra',
        // Add more fields as needed
    ];

    function __construct()
    {
        $this->db = \Config\Database::connect();
    }



    //TPTR - metody
    function getTPTRFN()
    {
        $builder = $this->db->table('clanky');
        $builder->select('*');
        $builder->where('hra = "TPTRFN"');
        $builder->join('autori', 'clanky.autor = autori.idautori', 'inner');

        $data = $builder->get()->getResult();
        return $data;
    }

    function getTPTRWOT()
    {
        $builder = $this->db->table('clanky');
        $builder->select('*');
        $builder->where('hra = "TPTRWOT"');
        $builder->join('autori', 'clanky.autor = autori.idautori', 'inner');

        $data = $builder->get()->getResult();
        return $data;
    }

    function getTPTRLOL()
    {
        $builder = $this->db->table('clanky');
        $builder->select('*');
        $builder->where('hra = "TPTRLOL"');
        $builder->join('autori', 'clanky.autor = autori.idautori', 'inner');

        $data = $builder->get()->getResult();
        return $data;
    }

    function getTPTRCP77()
    {
        $builder = $this->db->table('clanky');
        $builder->select('*');
        $builder->where('hra = "TPTRCP77"');
        $builder->join('autori', 'clanky.autor = autori.idautori', 'inner');

        $data = $builder->get()->getResult();
        return $data;
    }

    function getTPTRGTA()
    {
        $builder = $this->db->table('clanky');
        $builder->select('*');
        $builder->where('hra = "TPTRGTA"');
        $builder->join('autori', 'clanky.autor = autori.idautori', 'inner');

        $data = $builder->get()->getResult();
        return $data;
    }



    //Glitche - metody
    function getGlitcheFN()
    {
        $builder = $this->db->table('clanky');
        $builder->select('*');
        $builder->where('hra = "GlitcheFN"');
        $builder->join('autori', 'clanky.autor = autori.idautori', 'inner');

        $data = $builder->get()->getResult();
        return $data;
    }

    function getGlitcheWOT()
    {
        $builder = $this->db->table('clanky');
        $builder->select('*');
        $builder->where('hra = "GlitcheWOT"');
        $builder->join('autori', 'clanky.autor = autori.idautori', 'inner');

        $data = $builder->get()->getResult();
        return $data;
    }

    function getGlitcheLOL()
    {
        $builder = $this->db->table('clanky');
        $builder->select('*');
        $builder->where('hra = "GlitcheLOL"');
        $builder->join('autori', 'clanky.autor = autori.idautori', 'inner');

        $data = $builder->get()->getResult();
        return $data;
    }

    function getGlitcheCP77()
    {
        $builder = $this->db->table('clanky');
        $builder->select('*');
        $builder->where('hra = "GlitcheCP77"');
        $builder->join('autori', 'clanky.autor = autori.idautori', 'inner');

        $data = $builder->get()->getResult();
        return $data;
    }

    function getGlitcheGTA()
    {
        $builder = $this->db->table('clanky');
        $builder->select('*');
        $builder->where('hra = "GlitcheGTA"');
        $builder->join('autori', 'clanky.autor = autori.idautori', 'inner');

        $data = $builder->get()->getResult();
        return $data;
    }



    //Metoda na tabulky
    function getclanek($id)
    {
        $builder = $this->db->table('clanky');
        $builder->select('*');
        $builder->where('idclanky', $id);

        $data = $builder->get()->getResult();
        return $data;
    }

    function addClanek($data) 
    {
        $builder = $this->db->table('clanky');

        $builder->insert($data);
        return true;
    }

    function smazClanek($data) 
    {
        $builder = $this->db->table('clanky');

        $builder->delete($data);
        return true;
    }

   
}
