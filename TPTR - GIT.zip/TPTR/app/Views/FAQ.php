<?php

$this->extend('layout/master');

$this->section('content');

?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<style>
	.accordion-item {
		background-color: #f8f9fa;
		border: none;
		border-radius: 10px;
		box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
		margin-bottom: 20px;
	}

	.accordion-item .accordion-header {
		background-color: #f8f9fa;
		border: none;
		padding: 15px;
	}

	.accordion-item .accordion-header button {
		color: #343a40;
		font-weight: bold;
		font-size: 18px;
		text-decoration: none;
		width: 100%;
		text-align: left;
		padding: 0;
		transition: color 0.3s ease;
	}

	.accordion-item .accordion-header button:hover {
		color: #007bff;
	}

	.accordion-item .accordion-body {
		padding: 20px;
		color: #6c757d;
	}
</style>

<div class="container mt-5">
	<div id="accordion">
		<div class="accordion-item">
			<div class="accordion-header" id="headingOne">
				<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
					Kde mě můžete kontaktovat?
				</button>
			</div>

			<div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
				<div class="accordion-body"><a href="https://www.instagram.com/vlada.valenta/">Instagram</a><p> - ve zprávách mi můžete kdykoliv napsat a já se Vám budu snažit co nejrychleji odpovědět.</p>
					<div class="accordion-body">
					</div>
				</div>
			</div>
		</div>

		<div class="accordion-item">
			<div class="accordion-header" id="headingTwo">
				<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
					Proč tenhle projekt vznikl?
				</button>
			</div>

			<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
				<div class="accordion-body">
					<p>Tahle stránka vznikla za účelem zlepšení se v programování webu a jako závěrečný projekt školního roku 2022/23. Její vedlejší účel do budoucna pěkně charakterizuje slovní spojení "testovací pole", kde bych si zkoušel různé věci, které se týkají webu.</p>
				</div>
			</div>
		</div>

		<div class="accordion-item">
			<div class="accordion-header" id="headingThree">
				<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
					Jak dlouho jsem na projektu pracoval?
				</button>
			</div>

			<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
				<div class="accordion-body">
					<p>Dohromady je to asi přes 10 hodin čisté práce, ale průběžně jsem na něm pracoval necelé dva měsíce.</p>
				</div>
			</div>
		</div>

		<div class="accordion-item">
			<div class="accordion-header" id="headingFour">
				<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
					Budu provádět další práce na projektu?
				</button>
			</div>

			<div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
				<div class="accordion-body">
					<p>Ano, budu. Projekt čeká v průběhu dalšího týdne postupné přidávání článku v sekci TPTR a glitchů. Také se budu soustředit na opravování chyb nalezeny v testovací fázi.</p>
				</div>
			</div>
		</div>

	</div>
</div>

<?php

echo $this->endSection();

?>