<?php

$this->extend('layout/master');

$this->section('content');

?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">






<?= $this->include('layout/tabulka'); ?>





<?php

echo $this->endSection();

?>