<?php

$this->extend('layout/master');

$this->section('content');

?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">







<?= $this->include('layout/tabulka'); ?>



<?php /*
if (isset($data)) {
    foreach ($data as $row) {
        /*print_r($row);
        echo '<br><br><br><br>';
        $radek = array($row->, $row->, $row->, $row->, $row->, $row->, $row->);
        $table->addRow($radek);
    }
}*/


?>




<?php

echo $this->endSection();

?>