<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the record ID from the form data
    $recordId = $_POST['idclanky'];

    // Perform the deletion query
    $db = new mysqli('localhost', 'root', '', 'clanky');
    $sql = "DELETE FROM table_name WHERE id = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param('i', $idclanky);
    $stmt->execute();

    // Check if the deletion was successful
    if ($stmt->affected_rows > 0) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record";
    }

    $stmt->close();
    $db->close();
}
?>
