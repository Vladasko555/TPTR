<?php

$this->extend('layout/master');

$this->section('content');

?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<style>

</style>

<div class="container mt-5">
    <div class="card-deck">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Přidat článek</h5>
                <!-- <p class="card-text"></p> -->

                <form action="<?= base_url("addclanek") ?>" method="POST">

                    <!-- <p>
                        <label for="firstName">First Name:</label>
                        <input type="text" name="first_name" id="firstName">
                    </p> -->

                    <p>
                        <label for="lastName">Hra: </label>
                        <input type="text" name="hra" id="hra">
                    </p>

                    <p>
                        <label for="Gender">Nadpis: </label>
                        <input type="text" name="nadpis" id="nadpis">
                    </p>

                    <p>
                        <label for="Address">Autor: </label>
                        <input type="text" name="autor" id="autor">
                    </p>

                    <p>
                        <label for="emailAddress">Text: </label>
                        <input type="text" name="text" id="text">
                    </p>

                    <input type="submit" value="Nový" ky class="btn btn-success btn-lg"> </a>
                    <!--<div class="card-footer">
                        <a href="<?= base_url('/new') ?>" ky class="btn btn-success btn-lg">Nový</a>
                    </div>-->
                </form>
            </div>
        </div>
    </div>

    <br>
    <hr>
    <br>

    <div class="card-deck">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Přidat článek</h5>
                <!-- <p class="card-text"></p> -->

                <form action="<?= base_url("addclanek") ?>" method="POST">

                    <p>
                        <label for="idclanky">ID článku: </label>
                        <input type="int" name="idclanky" id="idclanky">
                    </p>

                    <input type="submit" value="Smaž" ky class="btn btn-danger btn-lg"> </a>
                </form>

                <!--<div class="card-footer">
                        <a href="<?= base_url('/new') ?>" ky class="btn btn-success btn-lg">Nový</a>
                    </div>-->

            </div>
        </div>
    </div>

    <br>
    <hr>
    <br>

</div>















<!-- <div class="container mt-5">
            <div class="card-deck">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Smazat článek</h5>
                        <!-- <p class="card-text"></p> 
                    </div>
                    <div class="card-footer">
                        <a href="<?= base_url('/delete') ?>" ky class="btn btn-danger btn-lg">Smaž</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <div class="card-deck">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Upravit článek</h5>
                        <!-- <p class="card-text"></p> 
                    </div>
                    <div class="card-footer">
                        <a href="<?= base_url('/edit') ?>" ky class="btn btn-primary btn-lg">Uprav</a>
                    </div>
                </div>
            </div>
        </div> -->
</div>
</div>


<?php

echo $this->endSection();

?>