<?php

$this->extend('layout/master');

$this->section('content');

echo "<br>";
echo '<h1 class="text-center bg-dark container"><a href="https://www.zetor.cz/">PROSTŘEDKY FIRMY</a></h1>';
echo "<hr>";
$table = new \CodeIgniter\View\Table();
$table->setHeading("Název", "Rok výroby", "Výkon motoru", "Popis práce"); // názvy sloupečků

?>

</main>

<?php

if (isset($data)) {
    foreach ($data as $row) {
        //$cesta = base_url("assets/img/");
        //$vlajka = "<img src = '" . $cesta . "/" . $row->vlajka . "' style='height: 75px;'>";
        //$radek = array(Anchor("zavodnik/" . $row->idzeme, $row->nazev), $row->zkratka, $vlajka);
        $radek = array(Anchor('clanek/' . $row->idclanek, $row->nadpis), $row->text); // routa . co bude za routou /$1; slupec, který odkazuje
        $table->addRow($radek);
    }
}




$template = [
    'table_open' => '<table class="table table-striped table-dark">',
    'thead_open' => '<thead>',
    'thead_close' => '</thead>',
    'heading_row_start' => '<tr>',
    'heading_row_end' => '</tr>',
    'heading_cell_start' => '<th>',
    'heading_cell_end' => '</th>',
    'tfoot_open' => '<tfoot>',
    'tfoot_close' => '</tfoot>',
    'footing_row_start' => '<tr>',
    'footing_row_end' => '</tr>',
    'footing_cell_start' => '<td>',
    'footing_cell_end' => '</td>',
    'tbody_open' => '<tbody>',
    'tbody_close' => '</tbody>',
    'row_start' => '<tr>',
    'row_end' => '</tr>',
    'cell_start' => '<td>',
    'cell_end' => '</td>',
    'row_alt_start' => '<tr>',
    'row_alt_end' => '</tr>',
    'cell_alt_start' => '<td>',
    'cell_alt_end' => '</td>',
    'table_close' => '</table>'
];

$table->setTemplate($template);
echo "<div class=container>";
echo $table->generate();
echo "</div>";


echo $this->endSection();

?>