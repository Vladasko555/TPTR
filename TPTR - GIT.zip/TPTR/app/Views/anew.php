<?php

$this->extend('layout/master');

$this->section('content');

?>



<?php

// servername => localhost
// username => root
// password => empty
// database name => staff
$conn = mysqli_connect("localhost", "root", "", "clanky");

// Check connection
if ($conn === false) {
    die("ERROR: Could not connect. "
        . mysqli_connect_error());
}

// Taking all 5 values from the form data(input)
$first_name =  $_REQUEST['hra'];
$last_name = $_REQUEST['nadpis'];
$gender =  $_REQUEST['autor'];
$address = $_REQUEST['text'];
$email = $_REQUEST['datum_napsani'];

// Performing insert query execution
// here our table name is college
$sql = "INSERT INTO clanky  VALUES ('$hra','$nadpis','$autor','$text', '$datum_napsani')";

if (mysqli_query($conn, $sql)) {
    echo "<h3>data stored in a database successfully."
        . " Please browse your localhost php my admin"
        . " to view the updated data</h3>";

    echo nl2br("\n$hra\n $nadpis\n 
        $autor\n $text\n $datum_napsani");
} else {
    echo "ERROR: Hush! Sorry $sql. "
        . mysqli_error($conn);
}

// Close connection
mysqli_close($conn);
?>


