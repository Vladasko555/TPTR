<?php

$this->extend('layout/master');

$this->section('content');

?>


<div class="container">
    <h1><?php if (!empty($clanek)) : ?>
            <?php foreach ($clanek as $item) : ?>
                <p><?= $item->nadpis; ?><?php endforeach; ?>
                <?php else : ?>
                <p>No data available.</p>
            <?php endif; ?>
    </h1>

    <?php if (!empty($clanek)) : ?>
        <?php foreach ($clanek as $item) : ?>

            <p><?= $item->text; ?></p>
            <p><b>Datum napsání článku: </b><?= $item->datum_napsani; ?></p>
            <?php if ($item->autor == '0') : ?>
                <p><b>Autor: </b><?= $item->autor; ?> - Lim Fao</p>
            <?php elseif ($item->autor == '1') : ?>
                <p><b>Autor: </b><?= $item->autor; ?> - Lom Fai</p>
            <?php endif; ?>
        <?php endforeach; ?>
    <?php else : ?>
        <p>No data available.</p>
    <?php endif; ?>
</div>


<?php


echo $this->endSection();

?>