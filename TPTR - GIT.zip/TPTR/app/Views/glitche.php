<?php

$this->extend('layout/master');

$this->section('content');

?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<style>
    .card {
        background-color: #f8f9fa;
        border: none;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease;
        margin-bottom: 20px;
    }

    .card:hover {
        transform: scale(1.05);
    }

    .card-title {
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 10px;
    }

    .card-text {
        font-size: 16px;
        margin-bottom: 20px;
        color: #6c757d;
    }

    .card-footer {
        background-color: #f8f9fa;
        border-top: none;
        padding: 15px;
        text-align: center;
    }

    .btn {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 12px 20px;
        text-decoration: none;
        font-weight: bold;
        transition: background-color 0.3s ease;
    }

    .btn:hover {
        background-color: #0056b3;
    }
</style>

<div class="container mt-5">
    <div class="card-deck">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">GTA 5</h5>
                <p class="card-text">Grand Theft Auto V</p>
            </div>
            <div class="card-footer">
                <a href="<?= base_url('/GlitcheGTA') ?>"ky class="btn btn-primary btn-lg">Přejít na články</a>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Fortnite</h5>
                <p class="card-text">Battle Royale Hra</p>
            </div>
            <div class="card-footer">
                <a href="<?= base_url('/GlitcheFn') ?>"ky class="btn btn-primary btn-lg">Přejít na články</a>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">League of Legends</h5>
                <p class="card-text">MOBA Hra</p>
            </div>
            <div class="card-footer">
                <a href="<?= base_url('/GlitcheLOL') ?>" class="btn btn-primary btn-lg">Přejít na články</a>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">World of Tanks</h5>
                <p class="card-text">Bitva historických tanků</p>
            </div>
            <div class="card-footer">
                <a href="<?= base_url('/GlitcheWOT') ?>"ky class="btn btn-primary btn-lg">Přejít na články</a>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Cyberpunk 2077</h5>
                <p class="card-text">RPG budoucnosti</p>
            </div>
            <div class="card-footer">
                <a href="<?= base_url('/GlitcheCP77') ?>"ky class="btn btn-primary btn-lg">Přejít na články</a>
            </div>
        </div>

        <?php

echo $this->endSection();

?>