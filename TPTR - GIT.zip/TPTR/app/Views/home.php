<?php

$this->extend('layout/Master1');

$this->section('content');

?>

<main>

  <h1><a class="container FAQ" href="<?= base_url('/FAQ') ?>"></a>FAQ</h1>

  <a class="nav-link" href="<?= base_url('/TPTR') ?>">
    <div class="split left">
      <div class="centered text-white">
        <!-- <img src="img_avatar.png" alt="Avatar man"> -->
        <h2>Tipy a triky</h2>
        <p>k Vašemu úspěchu!</p>
      </div>
    </div>
  </a>

  <a class="nav-link" href="<?= base_url('/glitche') ?>">
    <div class="split right">
      <div class="centered">
        <!-- <img src="img_avatar.png" alt="Avatar man"> -->
        <h2>Glitche</h2>
        <p>pro nejlepší zábavu!</p>
      </div>
    </div>
  </a>

</main>

<?php $this->endSection(); ?>