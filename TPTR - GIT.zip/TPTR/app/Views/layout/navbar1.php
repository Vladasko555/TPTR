<style>
  .custom-bg {
    background: linear-gradient(
      to right,
      white 0%,
      white 50%,
      gray 50%,
      gray 100%
    );
  }
  a {
   color: blue !important;
  }
</style>

<nav class="navbar navbar-expand-lg  ">
  <!--<a class="navbar-brand text-center" href="<?= base_url('/') ?>">HOME</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>-->
  <div class=" justify-content-center collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav custom-bg">
      <li class="nav-item">
        <a class="nav-link " href="<?= base_url('/FAQ') ?>"><b>FAQ</b></a>
      </li>
    </ul>
  </div>
</nav>




<?



/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
