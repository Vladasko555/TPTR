<style>
  .custom-bg {
    background-color: black;
    color: white;
  }

 


  /* Default light mode styles */
  body {
    background-color: white;
    color: black;
  }

  /* Dark mode styles */
  body.dark-mode {
    background-color: black;
    color: white;
  }
</style>

<nav class="navbar navbar-expand-lg  ">
  <a class="navbar-brand text-center" href="<?= base_url('/') ?>"><b>Domů</b> </a>
  <button class="navbar-toggler FAQ" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class=" justify-content-center collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="<?= base_url('/FAQ') ?>"><b>FAQ</b></a>
      </li>
      <li>
        <div class="container">
          <div class="custom-control custom-switch pl-15 mt-2">
            <input type="checkbox" class="custom-control-input" id="darkModeSwitch">
            <label class="custom-control-label" for="darkModeSwitch">
              <p id="themeText">Tmavý režim</p>
            </label>
          </div>
        </div>
      </li>
    </ul>
  </div>
</nav>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    const darkModeSwitch = document.getElementById('darkModeSwitch');
    const themeText = document.getElementById('themeText');

    darkModeSwitch.addEventListener('change', function() {
      if (darkModeSwitch.checked) {
        document.body.classList.add('dark-mode');
        themeText.textContent = "Světlý režim";
      } else {
        document.body.classList.remove('dark-mode');
        themeText.textContent = "Tmavý režim";
      }
    });
  });
</script>




<?



/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
