<div class="container">
    <div class="row">
        <div class="col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Nadpis</th>
                        <th scope="col">Autor</th>
                        <th scope="col">Datum</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($data as $one ) : ?>
                    <tr>
                        <td><a href="<?= base_url("/clanky/".$one->idclanky); ?>"><?= $one->nadpis ?></a></td>
                        <td><?php if ($one->autor == '0'): ?>
                                <p>Autor: <?= $one->autor; ?> - Lim Fao</p>
                                    <?php elseif ($one->autor == '1'): ?>
                                <p>Autor: <?= $one->autor; ?> - Lom Fai</p>
                            <?php endif; ?>
                        </td>
                        <td><?= $one->datum_napsani ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



