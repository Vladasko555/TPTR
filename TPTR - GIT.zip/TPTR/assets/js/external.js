/*document.getElementById("demo").innerHTML = "Paragraph";
document.getElementById("demo").style.fontSize = "15px";
document.getElementById("demo").style.display = "block";

function myFunction() {
   alert("gratuluju, trefil ses na cudlik");
}


const nav = document.querySelector('nav');

window.addEventListener('scroll', () => {
  if (window.scrollY >= 200) {
    nav.classList.add('navbar-scroll-in');
  } else {
    nav.classList.remove('navbar-scroll-in');
  }*/

  document.addEventListener('DOMContentLoaded', function() {
    const darkModeSwitch = document.getElementById('darkModeSwitch');
    darkModeSwitch.addEventListener('change', function() {
      if (darkModeSwitch.checked) {
        document.body.classList.add('dark-mode');
      } else {
        document.body.classList.remove('dark-mode');
      }
    });
  });
  
  
